Para informa��es a respeito de instala��o de bibliotecas, acesso: http://www.arduino.cc/en/Guide/Libraries
