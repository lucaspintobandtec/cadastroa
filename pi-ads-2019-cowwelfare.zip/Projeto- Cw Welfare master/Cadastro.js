// validação cadastro 1
function validar() {
    ver_senha = Number(senha.value);
    ver_senha2 = Number(senha2.value);
    ver_tele = Number(tele.value);
    ver_cnpj = Number(cnpj.value)

    if (nome.value == "" || nome.value.length < 8) {
        alert("Preencha campo NOME corretamente!");
    }

    if (ver_cnpj == "") {
        alert("Preencha campo CNPJ corretamente!")
    }

    if (email.value == "" || email.value.indexOf('@') == -1 || email.value.indexOf('.') == -1) {
        alert("Preencha campo E-MAIL corretamente!");
    }

    if (ver_tele == "") {
        alert("Preencha campo TELEFONE corretamente!");
    }

    if (ver_senha !== ver_senha2 || ver_senha == "" || ver_senha2 == "") {
        alert(`Preencha campo SENHA corretamente!`);
    }
}
// validação cadastro login
function ValidarLogin() {
    ver_senha = Number(senhalogin.value);

    if (emaillogin.value == "" || emaillogin.value.indexOf('@') == -1 || emaillogin.value.indexOf('.') == -1) {
        alert("Preencha campo E-MAIL corretamente!");
    }
    if (ver_senha == "") {
        alert(`Preencha campo SENHA corretamente!`);
    }
}

// validação cadastro 2
function Validar2(){

}
